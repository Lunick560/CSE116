package edu.buffalo.cse116;

public class SnookerBall {
 private double mass;
 private double speed;

 public SnookerBall(double ans){
	 setMass(ans);
	 setSpeed(0.0);
 }
 	public double energy(){
 		return getMass()*0.5*getSpeed()*getSpeed();
 	}
 	public void hit(SnookerBall fine){
 		double newSpeed = this.getSpeed()*(this.getMass()-fine.getMass());
 		newSpeed= newSpeed + 2*fine.getMass()*fine.getSpeed();
 		newSpeed = newSpeed/(this.getMass()+fine.getMass());
 		double otherSpeed = fine.getSpeed()*(fine.getMass()-this.getMass());
 		otherSpeed = otherSpeed+2*this.getMass()*this.getSpeed();
 		otherSpeed=otherSpeed/(this.getMass()+fine.getMass());
 		
 		this.setSpeed(newSpeed);
 		fine.setSpeed(otherSpeed);
 	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public double getMass() {
		return mass;
	}
	public void setMass(double mass) {
		this.mass = mass;
	}
}
