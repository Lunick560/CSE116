package edu.buffalo.cse116;

import static org.junit.Assert.*;

import org.junit.Test;

public class SnookerBallTest {
@Test
public void testEnergy(){
	SnookerBall ft = new SnookerBall(6.5);
	ft.setSpeed(4.1);
	double ans = ft.energy();
	assertEquals(54.6325,ans,0.001);
}
@Test
public void testHit(){
	SnookerBall st1 = new SnookerBall(2.4);
	SnookerBall st2 = new SnookerBall(4.4);
	st1.setSpeed(100.1);
	st2.setSpeed(0.5);
	st2.hit(st1);
	assertEquals(2.3,st1.getMass(),0.01);
	assertEquals(-30.7179,st1.getSpeed(),0.01);
	assertEquals(4.4,st2.getMass(),0.01);
	assertEquals(68.8821,st2.getSpeed(),0.01);
}
}
