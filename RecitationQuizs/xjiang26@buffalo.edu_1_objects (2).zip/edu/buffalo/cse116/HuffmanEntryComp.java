package edu.buffalo.cse116;

import java.util.Comparator;

public class HuffmanEntryComp implements Comparator<HuffmanEntry> {
  @Override
  public int compare(HuffmanEntry o1, HuffmanEntry o2) {
    // TODO: Replace this with code of your own to earn the final 20 points
    if(o1.treeFreq<o2.treeFreq){
    	return -1;
    }else if(o1.treeFreq==o2.treeFreq){
    	return 0;
    
  }else{
	  return 1;
  }
  }
}
