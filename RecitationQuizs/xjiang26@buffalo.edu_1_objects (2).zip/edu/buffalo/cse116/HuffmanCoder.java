package edu.buffalo.cse116;

import java.util.PriorityQueue;

/**
 * Instances of this class will process a priority queue to create a Huffman coding -- an optimal prefix compression of
 * the data.
 *
 * @author Matthew Hertz
 * @author ADD YOUR NAME HERE
 */
public class HuffmanCoder {

  /** Priority queue instance to be used. */
  private PriorityQueue<HuffmanEntry> pq;

  /**
   * Creates a new instance of this class and assigns it to use the specified priority queue
   *
   * @param priorQ The priority queue to be used.
   */
  public HuffmanCoder(PriorityQueue<HuffmanEntry> priorQ) {
    pq = priorQ;
  }

  public void encodeTree() {
  while(pq.size()>1){
	  Entry newNode = new Entry();
	  HuffmanEntry small =pq.remove();
	  //pq.remove();
	  small.treeRoot.setParent(newNode);
	  newNode.setLeft(small.treeRoot);
	  HuffmanEntry smallToo = pq.remove();
	  newNode.setRight(smallToo.treeRoot);
	  HuffmanEntry newEnt = new HuffmanEntry();
	  newEnt.treeRoot=newNode;
	  newEnt.treeFreq=small.treeFreq+smallToo.treeFreq;
	  pq.add(newEnt);
  }
  }
}
