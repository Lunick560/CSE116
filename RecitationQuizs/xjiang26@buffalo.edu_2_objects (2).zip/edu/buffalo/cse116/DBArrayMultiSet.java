package edu.buffalo.cse116;

public class DBArrayMultiSet<E> extends AMS<E> {
public DBArrayMultiSet difference(AMS ans){
	DBArrayMultiSet retVal = new DBArrayMultiSet();
	for(int i =0; i <_size;i++){
		E elem=_store[i];
		if(!ans.contains(elem)){
			retVal.add(elem);
		}
	}
	return retVal;
}
public void minimize(){
	DBArrayMultiSet duplicates = new DBArrayMultiSet();
	for(int idx=0;idx<_size;idx++){
		E elem = _store[idx];
		if(duplicates.contains(elem)){
			this.remove(elem);
			idx = idx-1;
		}
		duplicates.add(elem);
	}
}
}
