package edu.buffalo.cse116;

import java.util.AbstractMap;
import java.util.Set;

/**
 * Instances of this class define a Map using a search tree. This search tree could be a BST or any of the subclasses of
 * BST that could be defined (later in CSE 250).
 *
 * @author Matthew Hertz
 */
public class BSTMap extends AbstractMap<Integer, String> {
  /** Binary search tree used to hold all the elements. */
  private BinarySearchTree<MapEnt> bst;

  /**
   * Creates a new empty instance of the {@code Map} which will use the default type of binary search tree instance.
   */
  public BSTMap() {
    this(new BinarySearchTree<MapEnt>());
  }
  
  /**
   * Creates a new empty instance of the {@code Map} which will use the given binary search tree instance to store its
   * data. Having the field passed in this way makes testing simpler and means this class will work with any type of
   * binary search tree we wish to define.
   *
   * @param tree Binary search tree instance which will be used to store the {@code MapEnt}s in this {@code Map}.
   */
  public BSTMap(BinarySearchTree<MapEnt> tree) {
    bst = tree;
  }
  
public String get(Integer KeyToFind){
	  MapEnt elem = new MapEnt(KeyToFind,null);
	  if(bst.contains(elem)){
		BSEntry<MapEnt> node = bst.getEntry(elem);
		elem=node.getElement();
		 return elem.getValue();
	  }else{
		  return null;
	  }
	  
  }
public String put(Integer keyToAdd, String valueToAdd){
  MapEnt newElem = new MapEnt(keyToAdd,valueToAdd);
  if(bst.contains(newElem)){
	  BSEntry<MapEnt> node = bst.getEntry(newElem);
	  MapEnt oldElem = node.getElement();
	  String retVal = oldElem.getValue();
	  node.setElement(newElem);
	  return retVal;
  }else{
	  bst.add(newElem);
	  return null;
  }
  
}
public Integer minKey(){
BSEntry<MapEnt> parent = bst.getRoot();	
while(parent.getLeft()!=null){
	parent = parent.getLeft();
}
return parent.getElement().getKey();



}

  // Ignore the methods below this comment, they will not be used but are needed for the code to compile.
  public Set<Entry<Integer, String>> entrySet() {
	    // Needed to complete the Map interface. Do not worry about this.
	    throw new UnsupportedOperationException("Not implemented this term!");
	  }

  
}
