package edu.buffalo.cse116;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.Test;

public class BirthdayParadoxTest {
@Test
public void testMixedIterator(){
	ArrayList<Integer> ans = new ArrayList<Integer>();
	ans.add(9);
	ans.add(1);
	ans.add(9);
	BirthdayParadox one = new BirthdayParadox();
	assertTrue(one.checkBirthday(ans));
}
@Test
public void testMixedIterable(){
	ArrayList<Integer> ans = new ArrayList<Integer>();
	ans.add(5);
	ans.add(6);
	ans.add(5);
	BirthdayParadox two = new BirthdayParadox();
	assertTrue(two.checkBirthday(ans));
}


}
