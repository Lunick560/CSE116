package edu.buffalo.cse116;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class BirthdayParadox {

  public boolean checkBirthday(Iterable<Integer> bdays) {
	 int[] seen = new int[365];
	 for(int i:bdays){
		 seen[i]=seen[i]+1;
	 }
	 boolean retVal;
	 retVal = false;
	 for(int i=1; i<seen.length;i++){
		 if(seen[i]>1){
			 retVal = true;
		 }
	 }
	 return retVal;
  }

  public boolean checkBirthday(Iterator<Integer> bdays) {
	  int[] seen = new int[365];
	  
	  for(int i=0;i<seen.length;i++){
		 seen[i]=seen[i]+1;
	  }
	  boolean retVal;
	  retVal = false;
	  for(int i=1;i<seen.length;i++){
		 if(seen[i]>1){
			 retVal=true;
		 }
	  }
	  return retVal;
  }
}
