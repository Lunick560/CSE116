package edu.buffalo.cse116;

import java.util.List;

/**
 * Instances of this class represent the roster of a sportsball team. This
 * includes two methods that allow for basic maintenance of this roster.
 * 
 * @author Matthew Hertz
 */

public class SportsballRoster {
   private List<Athlete> roster; 
	public SportsballRoster(List<Athlete> ans){
		roster = ans;
}
	public boolean trade(Athlete one, Athlete two){
		if(roster.contains(one)){
			int idx = roster.indexOf(one);
			roster.set(idx, two);
			return true;
		}else{
			return false;
		}
		
		
		
	}
	public Athlete topAthlete(){
		
		int indexBest =0;
		Athlete player = roster.get(0);
		double statBest = player.sportsStat();
		for(int i=0; i<roster.size();i++){
			player=roster.get(i);
			double curStat;
			if(statBest<=player.sportsStat()){
				statBest = player.sportsStat();
				indexBest=i;
			}
		}
		return roster.get(indexBest);
	}
	
	
}
