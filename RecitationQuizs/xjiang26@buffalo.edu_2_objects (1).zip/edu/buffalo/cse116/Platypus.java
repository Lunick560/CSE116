package edu.buffalo.cse116;

public class Platypus extends Mammal {
  private Bird ancestry;

  private int age;



  public Platypus(String hair, String egg, int years) {
	 super(hair);
	 ancestry = new Bird(egg);
	 age = years;
  }
  public String getHairColor(){
	  return super.getHairColor();
  }
  public void setHairColor(String ans){
	  super.setHairColor(ans);
  }
  public boolean isMature(){
	  if(age>=2){
		  return true;
	  }else{
		  return false;
	  }
  }
  public String getEggColor(){
	  return ancestry.getEggColor();
  }
  public void setEggColor(String ec){
	  	ancestry.setEggColor(ec);
  }
  public String toString() {
	  return "Mammal with hair of "+this.getHairColor()+" and eggs that are "+this.getEggColor();
  }

  public Mammal getMammalAspects() {
	 return Platypus.this;
  }

  public Bird getBirdAspects() {
	  return this.ancestry;
  }
}
