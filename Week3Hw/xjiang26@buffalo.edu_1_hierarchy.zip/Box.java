package edu.buffalo.cse116;

public class Box extends Square {
protected double height;
public double getHeight() {
return height;	
}
public void setHeight(double height) {
	 this.height=height;
} 
public Box(double length,double height){
	 super(length);
	 this.height=height;
}
	public double getArea() {

		  return Double.NaN;
	}
	public double getVolume() {
		return getLength()*getLength()*getHeight();
				}
	
}
