package edu.buffalo.cse116;

public class Cube extends Square {
	 public Cube(double l) {
		 super(l);
}
	public double getVolume() {
		return getLength()*getLength()*getLength();
	}
}
