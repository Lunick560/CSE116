package edu.buffalo.cse116;

public class Bullfrog implements Speaker {

	@Override
	public String noiseMade() {
		// TODO Auto-generated method stub
		return "Biggest rain we ever had";
	}
	@Override

	public String formatName(String name) {
		return "Rana catesbeiana "+name;
	}

}
