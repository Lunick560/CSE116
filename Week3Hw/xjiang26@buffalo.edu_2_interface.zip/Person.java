package edu.buffalo.cse116;

public class Person implements Speaker {

	private String emotion;
	public Person(String emotion) {

		this.emotion = emotion;

		}
	public String getEmotion() {
		return emotion;
	}
	public void setEmotion(String emotion) {
		this.emotion=emotion;
	}

@Override
	public String noiseMade() {
		
		return "Hello, I feel " +emotion;
	}

@Override
	public String formatName(String name) {
		
		return "Homo sapiens "+name;
	}

}
