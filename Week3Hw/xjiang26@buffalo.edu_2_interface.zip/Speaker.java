package edu.buffalo.cse116;

public interface Speaker {
public String noiseMade();
public  String formatName(String name);
}
