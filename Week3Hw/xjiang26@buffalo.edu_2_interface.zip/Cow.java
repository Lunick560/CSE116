package edu.buffalo.cse116;

public class Cow implements Speaker {
@Override
	public String noiseMade() {
		
		return "Moo";
	}
@Override
	public String formatName(String name) {
	
		// TODO Auto-generated method stub
		return "Bos taurus "+ name ;
	}

}
