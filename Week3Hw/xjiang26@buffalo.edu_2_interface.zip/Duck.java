package edu.buffalo.cse116;

public class Duck implements Speaker {

	@Override
	public String noiseMade() {
		return "Quack";
	}
	@Override
	
	public String formatName(String name) {

		return "Anas platyrhynchos "+name;
	}

}
