package edu.buffalo.cse116;

import static org.junit.Assert.*;

import org.junit.Test;

public class VWCarTest {
@Test
public void test1() {
	VWCar testSubject = new VWCar();
	double ans = testSubject.mpg(10, 2);
	assertEquals(5.0,ans,0.01);
}
@Test
public void test2() {
	VWCar testSub = new VWCar();
	double ans = testSub.mpg(0,0);
	assertEquals(-1,ans,0.001);
}
@Test
public void test3() {
VWCar testS = new VWCar();
double ans = testS.mpg(0, 2);
assertEquals(0,ans,0.0001);

}
@Test 
public void test4() {
	VWCar Ts=new VWCar();
	double ans = Ts.mpg(4, 0);
	assertEquals(-1,ans,0.0001);
}
@Test
public void test5() {
	VWCar Ts = new VWCar();
	 Ts.resetReadings(390);
	 double ans = Ts.mpg(610, 10);
	 assertEquals(22.0,ans,0.001);
}
@Test
public void test6() {
	VWCar Ts = new VWCar();
	Ts.resetReadings(391);
	double ans = Ts.mpg(610, 10);
	assertEquals(21.9,ans,0.001);
}
}
