package edu.buffalo.cse116;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.EmptyStackException;

import org.junit.Test;

public class ProperStackTest {
  
   public static ProperStack<Integer> properStock;

   //Method to test constructor of ProperStock
   @Test
   public void testConstructor() {  
     
       //Create new proper stock object
       properStock = new ProperStack<Integer>();
     
       //After object creation the properStock will point some value
       assertNotNull(properStock);
   }

   //Method to test push operation
   @Test
   public void testPushOperation() {  

       //Create new proper stock object
       properStock = new ProperStack<Integer>();
     
       //For empty stack condition
       try {
           assertTrue(properStock.peek()==null);
       } catch(EmptyStackException e) {
       }
     
       //push element 10 on top of stack
       properStock.push(30);
     
       //Check the peek value
       assertTrue(properStock.peek()==30);
     
       //push element 10 on top of stack
       properStock.push(40);
     
       //Check the peek value
       assertTrue(properStock.peek()==40);

   }

   //Method to test pop operation
   @Test
   public void testPopOperation() {  

       //Create new proper stock object
       properStock = new ProperStack<Integer>();

       try {
         
           //For empty stack condition
           try {
               properStock.pop();
           } catch(EmptyStackException e) {
           }
            
           //push element 10 on top of stack
           properStock.push(10);
         
           //Check the peek value
           assertTrue(properStock.peek()==10);
         
           //push element 10 on top of stack
           properStock.push(20);
         
           //Check the peek value
           assertTrue(properStock.peek()==20);

           //pop element 20 from stack
           Integer poppedElement = properStock.pop();
         
           //Check the peek value
           assertTrue(poppedElement==20);
         
           //pop element 10 from stack
           poppedElement = properStock.pop();
         
           //Check the peek value
           assertTrue(poppedElement==10);
         
       } catch(Exception e) {
         
       }
     

   }
}