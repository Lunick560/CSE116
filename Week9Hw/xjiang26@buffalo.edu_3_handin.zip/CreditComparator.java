package edu.buffalo.cse116;

import java.util.Comparator;

/**
 * Class that can be used to compare two {@link Student}s by the number of credits they have earned. Since the number of
 * credits is related to the student's standing, this could be used when trying to sort students and then split them
 * into teams.
 *
 * @author Matthew Hertz
 * @author YOUR NAME HERE
 */
public class CreditComparator implements Comparator<Student> {

	@Override
	public int compare(Student arg0, Student arg1) {
		double c1=arg0.getCredits();
		double c2=arg1.getCredits();
		int well = arg0.compareTo(arg1);
		if(c1>c2){
			return 1;
		}
		if(c1>c2){
			return -1;
		}
		if(c1==c2){
			return 0;
		}
		if(well<0){
			return -1;
		}
		if(well>0){
			return 1;
		
		}else{
		return 0;
	}

	}

}
