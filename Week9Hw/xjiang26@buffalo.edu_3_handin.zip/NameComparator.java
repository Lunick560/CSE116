package edu.buffalo.cse116;

import java.util.Comparator;

/**
 * Class that can be used to alphabetize {@link Student}s. This should use the {@link Student#getName()} to get the two
 * students' names. It then uses the fact that {@code String} is already comparable to compare the Strings.
 *
 * @author Matthew Hertz
 * @author YOUR NAME HERE
 */
public class NameComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		String s1 = o1.getName();
		String s2 = o2.getName();
		if(s1.compareTo(s2)>0){
			return 1;
		}
		if(s1.compareTo(s2)<0){
			return -1;
		}
		return 0;
	}

}
