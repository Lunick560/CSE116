package edu.buffalo.cse116;

/**
 * When correctly implemented, this class will complete the Visitor pattern and create a system which calculates and
 * sets node's heights. It is important that each of the methods only calculate and set the height in the AVLEntry
 * provided as a parameter.
 *
 * @author Matthew Hertz
 */
public class HeightCalculatorVisitor<E> implements TreeVisitor<E, Void, Integer> {

  /**
   * Sets the height of the leaf node and then returns this height. By definition, leaves have a height of 0.
   */
  public Integer visitLeaf(Entry<E> leaf, Void data) {
		leaf.setHeight(0);
		return leaf.getHeight();
		}

  public Integer visitInterior(Entry<E> node, Void data) {
	  //1 greater than the taller child, assume node has child
	  node.setHeight(1);
	  Integer nodeHeight;
	  if(node.getLeft()!=null) {
		  node.getLeft().apply(this, data);
	  return node.getHeight();
	  }else if(node.getRight()!=null) {
		  node.getRight().apply(this, data);
		  return node.getHeight();
	  }
	  if(node.getLeft()!=null&&node.getRight()!=null) {
		   node.getLeft().apply(this, data);          
		   node.getRight().apply(this, data);         
		   if(node.getLeft().getHeight()>=node.getRight().getHeight()){              
			   nodeHeight= node.getLeft().getHeight()+1;         
			   node.setHeight(nodeHeight);   
		   } else if(node.getRight().getHeight()<=node.getLeft().getHeight()){         
				  nodeHeight = node.getRight().getHeight()+1;         
				  node.setHeight(nodeHeight);
				  node.apply(this, data);
					  
				  }else if(node.getRight()==null&&node.getLeft()!=null){
					  nodeHeight = node.getLeft().getHeight()+1;
					  node.setHeight(nodeHeight);
					  node.apply(this, data);
				  }else {
					  nodeHeight = node.getRight().getHeight()+1;
					  node.setHeight(nodeHeight);
					  node.apply(this, data);
				  }
			   
		   }      
		  
	  
	return node.getHeight();
  }
	  

  public Void getInitialValue() {
	  return null;
  }

}
