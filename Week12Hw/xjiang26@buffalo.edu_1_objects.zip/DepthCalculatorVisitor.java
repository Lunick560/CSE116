package edu.buffalo.cse116;
/**
 * When correctly implemented, this class will complete the Visitor pattern and create a system which calculates and
 * sets node's depths. It is important that each of the methods only calculate and set the depth in the AVLEntry
 * provided as a parameter.
 *
 * @author Matthew Hertz
 */
public class DepthCalculatorVisitor<E> implements TreeVisitor<E, Integer, Void> {

  /**
   * Sets the depth of the leaf node to the value that had been calculated.
   */
  public Void visitLeaf(Entry<E> leaf, Integer depth) {
	  leaf.setDepth(depth);
	  leaf.getDepth();
	return null;
	  // This visitor does not need a return value, so we will always return null
	
  }

  public Void visitInterior(Entry<E> node, Integer depth) {
node.setDepth(depth);
//assume node has child
	if(node.getLeft()!=null) {
	node.getLeft().apply(this, depth+1);
}
if(node.getRight()!=null) {
	node.getRight().apply(this, depth+1);
	
}
return null;    
// This visitor does not need a return value, so we will always return null
  }

  public Integer getInitialValue() {
	  return 0;
  }

}
