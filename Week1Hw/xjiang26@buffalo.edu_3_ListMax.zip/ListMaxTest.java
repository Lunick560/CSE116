package edu.buffalo.cse116;

import java.util.ArrayList;

import org.junit.Test;

import static org.junit.Assert.*;

public class ListMaxTest {
	@Test
	public void testListMax01() {
		ArrayList<Double> list = new ArrayList<Double>();
		list.add(4.0);
		list.add(12.0);
		list.add(9.0);
		list.add(null);
		list.add(0.0);
		list.add(6.0);
		double expected = 12.0;
		ListMax lm = new ListMax(list);
		double actual = lm.getLargest();
		assertEquals(expected, actual, 0.0);
	}
}
