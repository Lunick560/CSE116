package edu.buffalo.cse116;

public class MightBeFixableException extends Exception{
	
	public MightBeFixableException(String ans) {
      super(ans);	
}
}
