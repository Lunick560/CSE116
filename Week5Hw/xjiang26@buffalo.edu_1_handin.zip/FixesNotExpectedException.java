package edu.buffalo.cse116;

public class FixesNotExpectedException extends RuntimeException {
 public FixesNotExpectedException(){
	 super("TIFU: This exception was raised.");
 }
}
