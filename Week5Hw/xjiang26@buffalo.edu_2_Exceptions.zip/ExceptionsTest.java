package edu.buffalo.cse116;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ExceptionsTest {
	class DealWithMeException extends Exception {

		   private static final long serialVersionUID = 1L;

		   public DealWithMeException(String message) {

		super(message);

		}

		}

		class UnfixableException extends RuntimeException{

		   private static final long serialVersionUID = -1955867571127679581L;

		       public UnfixableException(String message) {

		      super(message);

		      }

		   }
  @Test
  public final void testCheckedException() {
    Class<DealWithMeException> cut = DealWithMeException.class;
    assertEquals("To make a class a checked exception it needs be a subclass of the appropriate Java class",
                 Exception.class, cut.getSuperclass());
  }

  @Test
  public final void testUncheckedException() {
    Class<UnfixableException> cut = UnfixableException.class;
    assertEquals("To make a class an unchecked exception it needs be a subclass of the appropriate Java class",
                 RuntimeException.class, cut.getSuperclass());
  }

}
