package edu.buffalo.cse116;

/**
 * Instances of this class represent the name of a person.
 *
 * @author Matthew Hertz
 */
public class Name implements Comparable<Name> {
  /**
   * First, often referred to as &quot;Christian&quot;, name of the person.
   */
  private String lastName;

  /**
   * Last or family name of the person.
   */
  private String firstName;

  /**
   * Create a new instance of Name with the given first and last names.
   *
   * @param f First name of the person.
   * @param l Last name of the person.
   */
  public Name(String f, String l) {
    firstName = f;
    lastName = l;
  }

  /**
   * Get the first name for this person.
   *
   * @return Person's Christian name.
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * Get the last name for this person.
   *
   * @return Person's family name.
   */
  public String getLastName() {
    return lastName;
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder(lastName);
    sb.append(firstName);
    sb.setLength(20);
    return sb.toString();
  }

@Override
public int compareTo(Name o) {
	return (this.firstName+this.lastName).length()-(o.firstName+o.lastName).length();
}


}
