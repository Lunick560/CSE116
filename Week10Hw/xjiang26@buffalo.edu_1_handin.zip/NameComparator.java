package edu.buffalo.cse116;

import java.util.Comparator;


public class NameComparator implements Comparator<Name> {

	public int compare(Name o1, Name o2) {
		String s1 = o1.getLastName();
		String s2 = o2.getLastName();
		if(s1.compareTo(s2)>0){
			return 1;
		}
		if(s1.compareTo(s2)<0){
			return -1;
		}
		return 0;
	}

}
