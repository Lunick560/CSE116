package edu.buffalo.cse116;

/**
 * When correctly implemented, this class will complete the Visitor pattern and create a system which calculates and
 * sets node's heights. It is important that each of the methods only calculate and set the height in the AVLEntry
 * provided as a parameter.
 *
 * @author Matthew Hertz
 */
public class HeightCalculatorVisitor<E> implements TreeVisitor<E> {

  /**
   * Sets the height of the leaf node and then returns this height. By definition, leaves have a height of 0.
   */
  @Override
  public int visitLeaf(AVLEntry<E> leaf, int data) {
			
	 leaf.setHeight(0);
 int ans = leaf.getHeight();
 return ans;
  }
  @Override
  public int visitInterior(AVLEntry<E> node, int data) {
	  node.setHeight(1);
	  int retVal = node.getHeight();
  if(node.getLeft()!=null){
	  retVal +=node.getLeft().apply(this, data);
	  return retVal;
  }
  if(node.getRight()!=null){
	  retVal+=node.getRight().apply(this, data);
	  return retVal;
  }
  if(node.getRight()==null&&node.getLeft()==null){
	  node.setHeight(3);
	  retVal=node.getHeight();
	  return retVal;
  }
  return retVal;

  }

}
