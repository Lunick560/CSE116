package edu.buffalo.cse116;

import java.util.ArrayList;
import static org.junit.Assert.*;
import org.junit.Test;
public class RateCalculatorTest {

	@Test
	public void testRateCal01(){
		RateCalculator f = new RateCalculator();
		double rate1 = 3.0;
		double time1 = 5.0;
		double rate2 = 2.5;
		double time2 = 6.0;
		double rate3 = 0.0;
		double time3 = 10.0;
		double expected = 30;
		double actual = f.totalDistance(rate1, time1, rate2, time2, rate3, time3);
		assertEquals(expected,actual,0.0);
	}	
}
